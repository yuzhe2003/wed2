const flag = "";
document.addEventListener('DOMContentLoaded', function() {
    const contentDiv = document.getElementById('content');
    console.log('contentDiv',contentDiv)

    const searchResults = document.getElementById('searchResults');
    const errorMessage = document.getElementById('errorMessage');
    const clearButton = document.getElementById('clearButton');
    const searchForm = document.getElementById('searchForm');
    console.log('searchForm',searchForm)
    const searchButton = document.getElementById('searchButton');
    const donateButton = document.getElementById('donateButton');
    const fundraiserDetails = document.getElementById('fundraiserDetails');
  
    loadFundraiserPage();
  
    // Add event listeners to the navigation links
    const navLinks = document.querySelectorAll('nav ul li a');
    console.log(123,navLinks);
    navLinks.forEach(link => {
      link.addEventListener('click', function(event) {
        event.preventDefault();
        const page = this.getAttribute('href');
        window.location.href = page;
        loadPage(page);
        flag = "111"
        console.log(flag)
      });
    });
  
  
  
    function loadFundraiserPage() {
      const id = new URLSearchParams(window.location.search).get('id')
  
      donateButton.addEventListener('click', function() {
        alert('This feature is under construction');
      });
    }
  
    function loadPage(page) {
      switch (page) {
        case 'index.html':
          loadHomePage();
          break;
        case 'search.html':
            setTimeout(() => {
          loadSearchPage();
            }, 2000);
          break;
        case 'fundraiser.html':
          loadFundraiserPage();
          break;
        case 'about.html':
          // Implement about page here
          contentDiv.innerHTML = '<h2>Task made by XXX</h2>';
          break;
        default:
          contentDiv.innerHTML = '<h2>Unknown Page</h2>';
      }
    }
  });