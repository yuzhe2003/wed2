const mysql = require('mysql');

const db = mysql.createPool({
  host: '127.0.0.1',
  user: 'root',
  password: '123456',
  //Here is the name of the database to connect to
  database: 'crowdfunding_db',
  multipleStatements: true,
})

module.exports = db;