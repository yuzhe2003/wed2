const express = require('express');
const app = express();
const router = require('./routes');

//Parse the middleware using JSON body
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

//Set a static folder
app.use(express.static('public'));

//Use routing
app.use('/api', router);

//Set the port and start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));