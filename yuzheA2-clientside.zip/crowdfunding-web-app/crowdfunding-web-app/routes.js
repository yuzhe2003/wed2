const express = require('express');
const router = express.Router();
const db = require('./crowdfunding_db');

router.get('/fundraisers', (req, res) => {
  const sql = `
    SELECT F.*, C.name AS category_name
    FROM FUNDRAISER F
    JOIN CATEGORY C ON F.category_id = C.CATEGORY_ID
    WHERE F.ACTIVE = '1'
  `;
  db.query(sql, (err, results) => {
    if (err) {
      console.error(err);
      res.status(500).send('Server error');
    } else {
      res.json(results);
    }
  });
});

router.get('/categories', (req, res) => {
  const sql = 'SELECT * FROM CATEGORY;';
  db.query(sql, (err, results) => {
    if (err) {
      console.error(err);
      res.status(500).send('Server error');
    } else {
      res.json(results);
    }
  });
});

router.get('/search', (req, res) => {
  const { organizer, city, category } = req.query;

  //Initializing the SQL query
  let sql = `
    SELECT F.*, C.name AS category_name
    FROM FUNDRAISER F
    JOIN CATEGORY C ON F.category_id = C.CATEGORY_ID
    WHERE F.ACTIVE = '1'
  `;

  //For storage conditior
  const conditions = [];

  //Check each parameter and add it to the condition array
  if (organizer) {
    conditions.push(`F.organizer LIKE '%${organizer}%'`);
  }
  if (city) {
    conditions.push(`F.city LIKE '%${city}%'`);
  }
  if (category) {
    conditions.push(`C.name LIKE '%${category}%'`);
  }

  //If possible, concatenate it into an SQL query
  if (conditions.length > 0) {
    sql += ' AND ' + conditions.join(' AND ');
  }

console.log(sql)

  db.query(sql, (err, results) => {
    if (err) {
      console.error(err);
      res.status(500).send('Server error');
    } else {
      res.json(results);
    }
  });
});


router.get('/fundraiser/:id', (req, res) => {
  const id = req.params.id;
  const sql = `
    SELECT F.*, C.name AS category_name
    FROM FUNDRAISER F
    JOIN CATEGORY C ON F.category_id = C.CATEGORY_ID
    WHERE F.FUNDRAISER_ID = ?;
  `;
  db.query(sql, [id], (err, results) => {
    if (err) {
      console.error(err);
      res.status(500).send('Server error');
    } else if (results.length === 0) {
      res.status(404).send('No fundraiser found with the given ID.');
    } else {
      res.json(results[0]);
    }
  });
});

module.exports = router;