const mysql = require('mysql');

//Create a connection object
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'z20000908',
    database: 'crowdfunding_db'
  });

//Connect to database
db.connect((err) => {
  if (err) {
    console.error('Error connecting to database:', err);
    return;
  }
  console.log('Database connected!');

  //inquireinquire
  db.query('SELECT 1', (err, result) => {
    if (err) {
      console.error('Query failed:', err);
    } else {
      console.log('Query successful:', result);
    }
  });
});

module.exports = db;